import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.jupiter.api.Test;
import org.junit.platform.engine.support.descriptor.FileSystemSource;

class Aufgabe2TestCases {

	@Test
	void testFindingPrimes() {
		// TODO: check the code that searches for prime numbers 
		int[] arr = PrimeNumber.isPrime(10);
		
		// correct amount of prime numbers? 
		assertEquals(10, arr.length);
		
		// are all found numbers prime numbers? 
		boolean check = true;
		
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] <= 1) {
				check = false;
				break;
			}
			else {
				for(int j = 2; j <= arr[i] / 2; j++) {
					if((arr[i] % i) == 0) {
						check = false;
						break;
					}
				}
			}
		}
		assertEquals(true, check);
		
		// are there prime numbers missing?
		int[] checkArr = new int[] {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
		assertArrayEquals(checkArr, arr);
	}
	
	@Test
	void testCreateFile() {
		// TODO: check the code that creates a file 
		File file = ToFile.createFile("test");
		
		// is a file created?
		assertEquals(true, file.exists());
		
		// is it at the right place?
		String path = "test.txt";
		assertEquals(path, file.getPath());
		
		// is it created with the right name?
		String name = "test.txt";
		assertEquals(name, file.getName());
		
		// can you create a filename consisting numbers or signs? 
		File nameNumbers = ToFile.createFile("132465");
		File nameSigns = ToFile.createFile("!?=");
		
		assertEquals(true, nameNumbers.exists());
		assertEquals(false, nameSigns.exists());
	}
	
	@Test
	void testWriteIntoFile() {
		// TODO: check the code that writes into the file 
		File writeInto = ToFile.createFile("writeInto");
		
		// does it write all the numbers in the array? 
		int[] checkArr = new int[] {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
		String checkStr = "2 3 5 7 11 13 17 19 23 29 ";
		ToFile.writeInFile(writeInto, checkArr);
		try {
			assertEquals(checkStr, Files.readString(Paths.get(writeInto.getPath())));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// even with a very small or a very big amount of numbers? 
		// is there a space between the numbers?
		// does the numbers have the correct order? 
	}

}
